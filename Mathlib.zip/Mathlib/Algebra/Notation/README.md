# Basic algebraic notation

This subfolder contains definitions and very minimal theory related to the basic algebraic operators
like `0`, `1`, `+`, `-`, `*`, `/`, `+ᵥ`, `•`, `-ᵥ`.

The files in this subfolder should stay extremely early in the import hierarchy, and in particular
are forbidden from importing anything from `Algebra` outside of that subfolder.
