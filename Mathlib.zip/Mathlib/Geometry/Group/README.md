# Geometric group theory

This subfolder is destined to contain the formalisation of geometric group theory.

Geometric group theory is the study of finitely generated groups through their actions on geometric spaces.

## Topics

The geometric group theory topics currently covered are:
* Growth of groups
